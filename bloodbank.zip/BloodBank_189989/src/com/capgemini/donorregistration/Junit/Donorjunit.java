package com.capgemini.donorregistration.Junit;
//mport static org.junit.BeforeClass;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import com.capgemini.donorregistration.service.*;
import com.capgemini.donorregistration.bean.DonorRegistrationDetails;
import org.junit.BeforeClass.*;
import org.junit.BeforeClass;
class Donorjunit {
//import org.juint.BeforeClass;
	static DonorRegistrationDetails donorHelp;
	static  DonorRegistrationDetails don=null;
	private static Object donor;
	private static Object donorHelper;

	@Before
	public static void setUpTest() throws Exception {
		donorHelper = new DonorRegistrationDetails();
		System.out.println("Before class");
		donor = new DonorRegistrationDetails(5,"pooja","kuruva","9052268267","O",21,"hyderabad");
		donor=new DonorRegistrationDetails(7,"hemanth","pasham","9916331170","AB",22,"Gadwal");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Before class");
		 donorHelper = null;
		donor=null;
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Before");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("After");}

	@Test
	public void Test() {
		donorHelper.registration(donor);
		//int a=new donorHelper.displaydonor();
		assertEquals(5,donorHelper.displayDetails());
		//DonorRegistrationdetails donor=new DonorRegistrationdetails(9,"ram","raj","9523614782","AB",45,"Banglore");
		}
	
}
