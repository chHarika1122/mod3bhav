package com.capgemini.donorregistration.Junit;
//mport static org.junit.BeforeClass;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.donorregistration.bean.DonorRegistrationDetails;
import org.junit.BeforeClass.*;
import org.junit.BeforeClass;
class Donorjunit1 {
//import org.juint.BeforeClass;
	static DonorRegistrationDetails donorHelp;
	static  DonorRegistrationDetails don=null;
	@BeforeClass
	public static void BeforeClass()
	{
		donorHelp=new DonorRegistrationDetails();
		don=new DonorRegistrationDetails(2,"Nandu","Pratapni", "9177239993", "A", 42, "Hyd");
	}

}

