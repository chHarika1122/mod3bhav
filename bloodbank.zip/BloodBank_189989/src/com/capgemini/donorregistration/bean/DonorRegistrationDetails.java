package com.capgemini.donorregistration.bean;

public class DonorRegistrationDetails {
	public int registrationId; 
	
	public String firstName;
	public String lastName;
	public String mobileNo;
	public String bloodgroup;
	public int age;
	public String city;
	private static int reg=1004;
	
	public DonorRegistrationDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(int registrationId) {
		this.registrationId = ++reg;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getBloodgroup() {
		return bloodgroup;
	}

	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public DonorRegistrationDetails(int registrationId, String firstName, String lastName, String mobileNo,
			String bloodgroup, int age, String city) {
		super();
		this.registrationId = registrationId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.bloodgroup = bloodgroup;
		this.age = age;
		this.city = city;
	}

	@Override
	public String toString() {
		return "DonorRegistrationDetails [registrationId=" + registrationId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", mobileNo=" + mobileNo + ", bloodgroup=" + bloodgroup + ", age=" + age + ", city=" + city
				+ "]";
	}
	
	
	
}
