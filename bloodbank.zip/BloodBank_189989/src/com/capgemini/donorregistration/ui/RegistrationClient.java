package com.capgemini.donorregistration.ui;

import java.util.Scanner;

import com.capgemini.donorregistration.bean.DonorRegistrationDetails;
import com.capgemini.donorregistration.service.DonorRegistrationHelper;
import com.capgemini.donorregistration.service.DonorRegistrationValidator;




public class RegistrationClient {
	static int registrationId;
	static String firstName;
	static String lastName;
	static String mobileNo;
	static String bloodgroup;
	static int age;
	static String city;
	static DonorRegistrationDetails drd1 = new DonorRegistrationDetails(registrationId, firstName, lastName, mobileNo, bloodgroup, age, city   );
       
	static DonorRegistrationHelper collectionhelper=null;

	static DonorRegistrationValidator val=null;
	    static Scanner sc = new Scanner(System.in);
	   // static BankCollectionHelper collectionhelper=null;
	    
		public static void main(String args[]) {
			
		

			int choice=0;
			collectionhelper = new DonorRegistrationHelper();
			     val=new DonorRegistrationValidator();    
					while(true)
					{
						System.out.println("1. blood donor registration\n 2.display donor details\n 3.exit");
						System.out.println("\n enter your choice");
						choice = sc.nextInt();
						switch(choice)
						{
						case 1:registration(); break;
						case 2:displayDetails();break;
	
						default:System.exit(0);
						}
					}
			// TODO Auto-generated method stub

		}
		
		public static void registration()
		{  
			DonorRegistrationDetails drd= null;
			int reg=1004;
			 String firstName;
			 String lastName;
			 String mobileNo;
			 String bloodgroup;
			 int age;
			 String city;
			int registrationId=++reg;
			 	try
				{
					 System.out.println("enter firstName ");
					 firstName= sc.next();
				     if(val.validatefName(firstName))
				    
					
				    System.out.println(" enter  lastName");
				    lastName = sc.next();
				    //val.validatelName(lastName);
				 
				    System.out.println("enter mobileNo");
				    mobileNo = sc.next();
				   // val.validateMobileNo(mobileNo);
					
					 System.out.println("enter bloodgroup");
					 bloodgroup = sc.next();
					// val.validateBloodGroup(bloodgroup);
					 
					 System.out.println("enter age");
					 age = sc.nextInt();
					 //val.validateAge(age);
					 
					 System.out.println("city");
					 city = sc.next();
					// val.validateCity(city);
				
					drd= new DonorRegistrationDetails(registrationId, firstName, lastName, mobileNo, bloodgroup, age, city);
					
					collectionhelper.registration(drd);
					
					// collectionhelper.enterNewBankDetails(acc);
				 //System.out.println(bankList);
				 //System.out.println(acc.toString());
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
			 	//System.out.println(acc.toString());
			 	//System.out.println(drd.toString());
			 	
			}
		
		public static void displayDetails()
		{
			 collectionhelper.displayDetails();
		}
		
		
}
