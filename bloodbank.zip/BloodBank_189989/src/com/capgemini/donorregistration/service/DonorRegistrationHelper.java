package com.capgemini.donorregistration.service;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.donorregistration.bean.DonorRegistrationDetails;



;

public class DonorRegistrationHelper {
	static Scanner s=new Scanner(System.in); 
	public static ArrayList<DonorRegistrationDetails>bankList=null;
	static
	{
		bankList=new ArrayList<DonorRegistrationDetails>();
		 //Person accHolder = new Person("smith",34);
		DonorRegistrationDetails a = new DonorRegistrationDetails(1,"vijay","patil","9025678090","a",40,"pune");
		DonorRegistrationDetails a1 = new DonorRegistrationDetails(2,"raju","pakhare","9582348900","b",45,"Mumbai");
		DonorRegistrationDetails a2 = new DonorRegistrationDetails(3,"nikhil","katekar","9766234200","o",35,"delhi");
		// Person accHolder1 = new Person("kathy",40);
		
		
		
		
		bankList.add(a);
		bankList.add(a1);
		bankList.add(a2);
		}
	
	public void registration(DonorRegistrationDetails drd)
	{
		
		bankList.add(drd);
		
		System.out.println("blood donor registration done successfully with registration id  "+bankList.get(bankList.size()-1).registrationId);
	  //  System.out.println(bankList.toString().registrationId);
	}
	
	public void displayDetails()
	{
		int regis;
		System.out.println("Enter registration number");
		regis=s.nextInt();
		int counter=0;
		int temp=0;
		boolean b = false;
		for(DonorRegistrationDetails b1 : bankList)
		{ 
			counter++;
			   if(b1.getRegistrationId()==regis)
			   {
				    b=true;		  				    
					temp=counter;
					System.out.println(bankList.get((temp-1)).toString());
					
				  }
			     
			}
		
		if(b==false)
		{
			System.out.println("Invalid registrationid .\n Enter a valid id");
		}
		
	}
	
	
	
	/*public static ArrayList<Account> getBankList() {
		return bankList;
	}
	public static void setBankList(ArrayList<Account> bankList) {
		BankCollectionHelper.bankList = bankList;*/
//	}
	
}
