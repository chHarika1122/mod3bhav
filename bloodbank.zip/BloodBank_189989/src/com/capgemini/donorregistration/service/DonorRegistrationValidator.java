package com.capgemini.donorregistration.service;

import java.util.regex.Pattern;

import com.capgemini.donorregistration.exception.DonorRegistrationException;



public class DonorRegistrationValidator {

	public static boolean validatefName(String firstName) throws DonorRegistrationException
	{
		String custPattern="[A-Za-z]{4,12}";
		if(Pattern.matches(custPattern,firstName))
		{
			return true;
		}
		else
		{
			throw new DonorRegistrationException("First name should start with capital containing only characters with min of 4 and max of 12 characters are allowed");
		}
	}
	public static boolean validatelName(String lastName) throws DonorRegistrationException
	{
		String custPattern="[A-Za-z]{4,12}";
		if(Pattern.matches(custPattern,lastName))
		{
			return true;
		}
		else
		{
			throw new DonorRegistrationException("Last name should start with capital containing only characters with min of 4 and max of 12 characters are allowed");
		}
	}
	public static boolean validateMobileNo(String mobileNo) throws DonorRegistrationException
	{
		String IdPattern="[7|8|9][0-9]{10}";
		if(Pattern.matches(IdPattern,mobileNo))
		{
			return true;
		}
		else
		{
			throw new DonorRegistrationException("The mobile number should contain 10 digits and should start with 7 or 8 or 9 is allowed");
		}
	}
	public static boolean validateBloodGroup(String bloodgroup) throws DonorRegistrationException
	{
		String IdPattern="[A|B|O|AB]";
		if(Pattern.matches(IdPattern, bloodgroup))
		{
			return true;
		}
		else
		{
			throw new DonorRegistrationException("The blood groups must be A or B or O or AB is allowed");
		}
	}
	public static boolean validateAge(int age) throws DonorRegistrationException
	{
		Integer.toString(age);
		String IdPattern="\\d[1-9]";
		if(age>18 && age<66)
		{
			return true;
		}
		else
		{
			return false;
			//throw new DonorRegistrationException("Only digits are allowed");
		}
	}
	public static boolean validateCity(String city) throws DonorRegistrationException
	{
		String IdPattern="([a - zA - Z] + |[a - zA - Z] + \\s[a - zA - Z] + )";
		if(Pattern.matches(IdPattern,city))
		{
			return true;
		}
		else
		{
			throw new DonorRegistrationException("Only names of cities are allowed");
		}
	}
}
